import React from 'react'
import { render } from 'react-dom'
import { Stopwatch } from './containers/Stopwatch'

render(<Stopwatch />, document.getElementById('root'))